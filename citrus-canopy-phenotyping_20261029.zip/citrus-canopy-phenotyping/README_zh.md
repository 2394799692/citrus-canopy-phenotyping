# 柑橘冠层结构表型论文统计复现配套仓库

本仓库用于从冻结逐树预测与参考值复算论文统计结果。英文主入口为 [README.md](README.md)。没有重新训练模型、修改人工冠形、改变DR/AS参考或覆盖论文。

## 运行方式

在Windows安装Python 3.10后，解压仓库并在根目录运行：

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe verify_release.py
.\.venv\Scripts\python.exe reproduce_paper_statistics.py --data-dir data --out-dir reproduced
```

结果写入`reproduced/`。核心复算不需要627份原始点云、MATLAB、GPU、模型权重或APP账号。完整模型推理与手机软件由配套工具另行提供，未混入这个最小统计仓库。

## 科研口径

最终数据为627条观测、515个登记树身份、DR有效541条、AS有效627条。主开发分析315条；原56株三期为168条观测。所有冻结预测的重复先按损失聚合，不能先平均预测再算指标。

历史外部原DR34/AS35与去除两组高重合测试记录后的DR32/AS33分别报告。515是登记身份数，不等于已证明相互独立的生物树数量。历史637条、118株及原76株留形实验保留在`SourceData/archive_E48/`，不用于替换最终口径。

## 公开数据与配套重建软件

此前公开的Zenodo归档：[https://doi.org/10.5281/zenodo.16562849](https://doi.org/10.5281/zenodo.16562849)。根据作者提供的发布说明，该归档提供LiDAR点云、RGB冠层图像，以及执行DR冠层体积和AS外冠层表面积重建的Windows桌面程序。程序支持单株点云、单株与批量处理，不依赖MATLAB。

这是独立的历史发布版本，文件范围和参数应以该归档自身文档为准，不将其自动等同于本仓库全部最终观测。

## 中柑慧橘Android应用

下载入口：[https://down.scxys.com/aims-v2.0/farming-apps-down.html](https://down.scxys.com/aims-v2.0/farming-apps-down.html)。可联系作者申请试用账号使用主要功能。应用关联冠层尺寸、图像、结构估计和单株记录。APP源工程、安装程序及账号不随本仓库打包，也不是统计复算的前提。

## 专利披露

已核实的中国发明专利申请：**一种果树冠层体积和表面积估计方法**，申请号 **202611532440.0**，申请日 **2026年9月30日**，受理通知发文日 **2026年9月30日**。申请人为西南大学柑桔研究所、中国农业科学院农业资源与农业区划研究所。

本仓库按申请已受理披露，不表述为专利已授权。详见[PATENTS.md](PATENTS.md)和机器可读专利记录。通知书中代理人电话、通信地址及其他行政信息未放入公开包。

## 本轮公开整理

补充顶层README、配套工具、专利与引用信息；只将SourceData中的本机绝对路径元数据替换为`source-ref:`标识，保留其他单元格、行列顺序及科研数据。`data/`、统计脚本和预期结果与输入包保持字节一致。重新生成SHA256清单，避免沿用已引用缺失README的旧清单。

本次未替作者选择开源许可证或授予专利实施许可，见[LICENSE_STATUS.md](LICENSE_STATUS.md)。论文尚未在本仓库中填入正式发表DOI或虚构GitHub地址。
