# Related patent application

The authors disclose the following Chinese invention patent application related to the canopy volume and surface-area estimation work.

| Field | Verified information |
|---|---|
| Chinese title | 一种果树冠层体积和表面积估计方法 |
| English title | A method for estimating fruit-tree canopy volume and surface area (unofficial translation) |
| Application number | **202611532440.0** |
| Filing date | **30 September 2026** |
| Acceptance-notice issue date | **30 September 2026** |
| Office | China National Intellectual Property Administration (CNIPA) |
| Documented status | Application accepted for processing, according to the supplied acceptance notice |
| Applicants | 西南大学柑桔研究所; 中国农业科学院农业资源与农业区划研究所 |
| Applicant names in English | Citrus Research Institute, Southwest University; Institute of Agricultural Resources and Regional Planning, Chinese Academy of Agricultural Sciences |
| Inventors, as listed in the notice | 郑永强, 李文杰, 刘文欢, 雷振中, 李顺心, 马岩岩, 于浩然, 陈栋旭 |

Acceptance of an application does not establish that a patent has been granted. No grant number, publication number, or current examination outcome is asserted here. The filing and acceptance dates above are both taken from the notice, not inferred from its filename.

The full administrative notice is retained by the authors. Its agent contact details, mailing address, and administrative identifiers are omitted from this public companion. The verified fields and a source-document checksum are provided in [docs/patent_disclosure.json](docs/patent_disclosure.json).

This is the one related application verified for this repository preparation. Additional applications should be added only when supporting records are available. Repository availability does not itself specify a patent licence; see [LICENSE_STATUS.md](LICENSE_STATUS.md).
