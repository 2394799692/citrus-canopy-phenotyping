"""Portable audit plot from reproduced statistics; not a paper-layout replacement."""
from pathlib import Path
import argparse
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def main(source,out):
    d=pd.read_csv(source);models=['AllometricLog','FixedGFS','FreeGFS'];cohorts=['Internal315','Historical35','September108'];colors=['#777777','#25817D','#C28048']
    fig,axes=plt.subplots(1,2,figsize=(8,3.8),layout='constrained')
    for ax,trait,label in zip(axes,['volume','surface_area'],['(a)','(b)']):
        for j,(model,color) in enumerate(zip(models,colors)):
            z=d[(d.trait==trait)&(d.model==model)].set_index('evaluation').loc[cohorts]
            ax.scatter(z.logRMSE,[i+(j-1)*.17 for i in range(3)],label=model,color=color,marker=['o','s','^'][j],s=35)
        ax.set(yticks=range(3),yticklabels=cohorts,xlabel='logRMSE',title=trait.replace('_',' '));ax.invert_yaxis();ax.spines[['top','right']].set_visible(False);ax.text(.5,1.10,label,ha='center',fontweight='bold',transform=ax.transAxes)
    axes[1].legend(frameon=False,loc='best',fontsize=8)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    for ext in ['png','pdf','svg']:fig.savefig(out.with_suffix('.'+ext),dpi=300)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',default='reproduced/reproduced_principal_performance.csv');p.add_argument('--output',default='reproduced/core_result_overview');a=p.parse_args();main(a.source,a.output)
