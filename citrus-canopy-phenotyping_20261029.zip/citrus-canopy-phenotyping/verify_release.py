"""Verify packaged SHA-256 values. No research-drive access is required."""
from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'SHA256.json').read_text(encoding='utf-8'))
failures=[]
for item in manifest['files']:
    p=ROOT/item['path']
    try:p.resolve().relative_to(ROOT.resolve())
    except ValueError:failures.append(item['path']+': invalid path');continue
    if not p.is_file():failures.append(item['path']+': missing');continue
    if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:failures.append(item['path']+': hash mismatch')
print(json.dumps(dict(verified_files=len(manifest['files']),passed=not failures,failures=failures),ensure_ascii=False,indent=2))
sys.exit(1 if failures else 0)
