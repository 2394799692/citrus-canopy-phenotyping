# Source Data versions

Current-cohort tables in this folder use the final627 observations/515 identities and E52 manual labels. Main315 internal predictions and the original56 longitudinal subgroup are unchanged. New files list final eligibility, crown-form results, expanded315 form holdouts and explanatory decompositions. No regression model was selected again.

archive_E48 retains the original source evidence byte-for-byte. Its archive-coverage, old76-form, historical118 external and technical-audit denominators are historical versions, not the current E53 population. They are retained for traceability and are not used to describe current overall coverage. Technical tests selected entirely from retained cases remain valid as executed. Source population impacts are listed in E53 analysis audit files. The new interval summaries filter saved test predictions only; proper training/calibration models remain separate from full315 point fits.
