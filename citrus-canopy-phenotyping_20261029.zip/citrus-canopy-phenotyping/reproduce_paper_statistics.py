"""Portable metric/paired-statistic reproduction from frozen OOF predictions.
Usage: python reproduce_paper_statistics.py --data-dir data --out-dir reproduced
No model fitting. Repeated predictions are aggregated as losses, never ensembled.
"""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd

def losses(z):
    q=z.copy();e=q.prediction-q.reference;q['SE']=e**2;q['AE']=abs(e);q['LE']=np.log(q.prediction/q.reference)**2;q['Bias']=e
    return q
def units(z):
    q=losses(z);r=q.groupby('record_id').agg(SE=('SE','mean'),AE=('AE','mean'),LE=('LE','mean'),Bias=('Bias','mean'),reference=('reference','first'),physical_id=('physical_id','first'))
    return r.groupby('physical_id')[['SE','AE','LE','Bias','reference']].mean()
def metrics(z):
    u=units(z);v=float(np.mean((u.reference-u.reference.mean())**2))
    return dict(n_records=z.record_id.nunique(),n_registered_identities=len(u),RMSE=float(np.sqrt(u.SE.mean())),MAE=float(u.AE.mean()),logRMSE=float(np.sqrt(u.LE.mean())),Bias=float(u.Bias.mean()),R2=float(1-u.SE.mean()/v) if len(u)>=10 and v>0 else np.nan)
def main(data_dir,out_dir):
    data=Path(data_dir);out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    p=pd.read_csv(data/'principal_predictions.csv');expected=pd.read_csv(data/'frozen_performance.csv');rows=[]
    assert not p[['analysis','record_id','trait','model','repeat','fold']].duplicated().any()
    for (evaluation,trait,model),z in p.groupby(['evaluation','trait','model']):rows.append(dict(evaluation=evaluation,trait=trait,model=model,**metrics(z)))
    perf=pd.DataFrame(rows);perf.to_csv(out/'reproduced_principal_performance.csv',index=False)
    z=perf.merge(expected,on=['evaluation','trait','model'],suffixes=('_reproduced','_frozen'),validate='one_to_one')
    deltas={k:float(abs(z[k+'_reproduced']-z[k+'_frozen']).max()) for k in ['RMSE','MAE','logRMSE','Bias','R2']}
    assert max(deltas.values())<1e-10,deltas
    # Do not replace historical evaluation. Record two separate source-overlap sensitivities.
    external=p[p.evaluation=='Historical35'];sensitivity=[]
    for scope,omit in [('Original frozen 34/35',[]),('Remove confirmed high-overlap test records',['E0047','E0050']),('Conservative any-shared-XYZ sensitivity',['E0047','E0050','E0036'])]:
        for (trait,model),zz in external[~external.record_id.isin(omit)].groupby(['trait','model']):sensitivity.append(dict(scope=scope,removed_records=';'.join(omit),trait=trait,model=model,**metrics(zz)))
    pd.DataFrame(sensitivity).to_csv(out/'historical_external_independence_sensitivity.csv',index=False)
    # Freshly declared conditional bootstrap, preserving original CI tables separately.
    # These intervals are not asserted to equal earlier intervals using other RNG seeds.
    contrasts=[];rng=np.random.default_rng(2026102862)
    for (evaluation,trait),zz in p.groupby(['evaluation','trait']):
        for baseline,new in [('FixedG','FixedGFS'),('FreeG','FreeGFS'),('FixedGFS','FreeGFS'),('AllometricLog','FreeGFS')]:
            a=units(zz[zz.model==baseline]);b=units(zz[zz.model==new]);a=a.loc[a.index.intersection(b.index)];b=b.loc[a.index]
            av=a.LE.to_numpy();bv=b.LE.to_numpy();draw=rng.integers(0,len(a),size=(5000,len(a)));d=np.sqrt(bv[draw].mean(1))-np.sqrt(av[draw].mean(1))
            lo,hi=np.quantile(d,[.025,.975]);contrasts.append(dict(evaluation=evaluation,trait=trait,baseline=baseline,new=new,n_resampling_units=len(a),delta_logRMSE=float(np.sqrt(bv.mean())-np.sqrt(av.mean())),lower95=float(lo),upper95=float(hi),seed=2026102862,draws=5000,interval_scope='Conditional on frozen predictions; physical registration identities resampled; source-overlap caveat retained for historical cohort'))
    pd.DataFrame(contrasts).to_csv(out/'recomputed_conditional_paired_intervals_E62seed.csv',index=False)
    if (data/'loco_predictions.csv').is_file():
        loco=pd.read_csv(data/'loco_predictions.csv');lr=[]
        for (experiment,form,trait,model),zz in loco.groupby(['experiment','form','trait','model']):lr.append(dict(experiment=experiment,form=form,trait=trait,model=model,**metrics(zz)))
        pd.DataFrame(lr).to_csv(out/'reproduced_expanded315_form_holdout_and_controls.csv',index=False)
        if (data/'frozen_loco_performance.csv').exists():
            saved=pd.read_csv(data/'frozen_loco_performance.csv');check=pd.DataFrame(lr).merge(saved,on=['experiment','form','trait','model'],suffixes=('_reproduced','_frozen'),validate='one_to_one')
            assert all(np.max(abs(check[k+'_reproduced']-check[k+'_frozen']))<1e-10 for k in ['R2','RMSE','MAE','Bias','logRMSE'])
    if (data/'expanded466_predictions.csv').exists():
        ep=pd.read_csv(data/'expanded466_predictions.csv');em=[];es=[]
        for (evaluation,trait,model),zz in ep.groupby(['evaluation','trait','model']):
            em.append(dict(evaluation=evaluation,trait=trait,model=model,**metrics(zz)))
            if evaluation=='Historical35':
                for scope,omit in [('Original',[]),('Remove confirmed high-overlap test records',['E0047','E0050']),('Conservative any-shared-XYZ sensitivity',['E0047','E0050','E0036'])]:es.append(dict(scope=scope,trait=trait,model=model,**metrics(zz[~zz.record_id.isin(omit)])))
        pd.DataFrame(em).to_csv(out/'reproduced_expanded466_performance.csv',index=False)
        pd.DataFrame(es).to_csv(out/'expanded466_historical_independence_sensitivity.csv',index=False)
        if (data/'frozen_expanded466_performance.csv').exists():
            saved=pd.read_csv(data/'frozen_expanded466_performance.csv');check=pd.DataFrame(em).merge(saved,on=['evaluation','trait','model'],suffixes=('_reproduced','_frozen'),validate='one_to_one')
            assert all(np.max(abs(check[k+'_reproduced']-check[k+'_frozen']))<1e-10 for k in ['R2','RMSE','MAE','Bias','logRMSE'])
    result=dict(passed=True,principal_predictions=len(p),principal_performance_rows=len(perf),max_metric_differences=deltas,regression_fits=0,bootstrap_seed=2026102862,bootstrap_unit='Physical identity after averaging losses within records and records within identities',old_bootstrap_intervals_preserved_separately=True)
    (out/'reproduction_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-dir',default=str(Path(__file__).parent/'data'));p.add_argument('--out-dir',default=str(Path(__file__).parent/'reproduced'));a=p.parse_args();main(a.data_dir,a.out_dir)
