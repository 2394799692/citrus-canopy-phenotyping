# Licence status and related rights

No software or data-reuse licence has been selected for this repository preparation. This package therefore does not add MIT, Apache, Creative Commons, or a patent licence on the authors' behalf.

The related Chinese patent application is disclosed in [PATENTS.md](PATENTS.md). A disclosure of filing/acceptance is not an assertion of grant or a permission to practise any claimed invention.

The separate Zenodo archive and Zhonggan Huiju application retain their own distribution and reuse terms. Their terms are not automatically extended to the files in this repository.

For a reuse permission or licensing enquiry, contact the corresponding authors listed in the README. The rights holders may replace this notice with a confirmed licence when preparing an openly licensed release.
