# Change log

## Public companion preparation dated 2026-10-29

- Added English README and Chinese navigation, reproduction instructions, manuscript evidence map, companion-tool links, patent disclosure, and citation metadata.
- Recorded the verified filing/acceptance date of application 202611532440.0; omitted unnecessary administrative contact data from the public copy.
- Preserved executable input data, scripts, and expected results byte-for-byte. Replaced only machine-specific source-path cells in selected extended SourceData CSVs with stable provenance tokens. All other CSV values and row/column order were checked.
- Rebuilt the checksum manifest because the supplied ZIP's old manifest still referenced a missing top-level Chinese README.
- Retained current and historical analyses, independent-overlap sensitivities, and adverse model-comparison evidence without changing research results.
- Did not alter the manuscript, fit models, publish a repository, select an open-source licence, or assert an unverified publication DOI.
