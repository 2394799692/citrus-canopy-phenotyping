# Statistical reproducibility

## Metrics and aggregation

`prediction` and `reference` are positive values in the target trait's units. For each saved prediction, the script computes squared error, absolute error, squared natural-log ratio `ln(prediction/reference)^2`, and signed error `prediction-reference`.

Within each observation, those losses are averaged across its saved validation repeats. They are then averaged across observations of the same registered physical-tree identifier. RMSE is the square root of mean squared error; MAE and Bias are the respective mean losses; logRMSE is the square root of mean squared log ratio. R² uses the variance of identity-level reference values, following the frozen scoring implementation. The script does not report R² for groups smaller than ten identities or with zero reference variance.

Volume errors use m³; reconstructed-area errors use m². R² and logRMSE are dimensionless. Repeated fits, technical scaling conditions, and repeat observations do not increase the number of independent biological trees.

## Outputs

| Output | Interpretation |
|---|---|
| `reproduced_principal_performance.csv` | Forty rows of principal internal/external metrics, checked against `data/frozen_performance.csv` |
| `reproduced_expanded315_form_holdout_and_controls.csv` | Expanded crown-form holdout and matched-training controls, checked against frozen metrics |
| `reproduced_expanded466_performance.csv` | Expanded-training branch, with available frozen comparisons checked |
| `historical_external_independence_sensitivity.csv` | Original principal historical evaluation and two separately labelled overlap sensitivities |
| `expanded466_historical_independence_sensitivity.csv` | Corresponding historical sensitivity for the expanded-training branch |
| `recomputed_conditional_paired_intervals_E62seed.csv` | Freshly declared 5,000-draw conditional paired bootstrap, seed 2026102862 |
| `reproduction_audit.json` | Numeric comparison summary and successful completion status |

## Interpretation boundaries

- Original principal evaluation uses full-315 fitted point models where applicable. Conformal interval summaries in SourceData come from separately fitted proper-training/calibration submodels.
- Existing paired intervals are retained separately. The fresh bootstrap conditions on frozen predictions, resamples registered tree identities, and excludes model-refitting uncertainty. Its endpoints can differ from earlier analyses with other seeds.
- The known high-overlap pairs are D0322/E0050 and D0327/E0047. Original historical DR34/AS35 metrics are retained. Removing E0047/E0050 gives DR32/AS33. An additional sensitivity excludes E0036, which shares only ten exact coordinates with D0172 and is not established as a duplicate tree.
- Historical source-overlap caveats remain relevant to the original bootstrap outputs. Sensitivities do not silently replace the frozen data or registration identities.
- Technical alpha scaling uses 18 trees; conditions are technical repetitions. Fixed-alpha surface-scale properties do not establish a cause of external prediction errors.
- Development size-extreme results include the finding that FreeGFS area performance was not uniformly worse. Fixed scaling is not presented as universally superior in extrapolation.
- Phone images and point-cloud orthogonal projections have different input provenance. Companion software availability does not establish independent RGB deployment accuracy.

## Data versions

The current retained population is 627 observations/515 registration identities, DR541/AS627. Historical source tables retain earlier labels, eligibility versions, and denominators. `archive_E48` is evidence history, not an alternative replacement for the current master population. Technical results are preserved under their executed populations.

Source-path cells were converted to opaque `source-ref:` identifiers for this public copy. They are not runtime dependencies. Other scientific cell strings and their order are unchanged. The authors retain the private reverse provenance map. Current file hashes are in the root `SHA256.json`; historical hash columns retain their original source-version meaning.

## Runtime scope

Core dependencies: Python 3.10, NumPy 1.26.4, pandas 2.3.3. Optional plotting adds Matplotlib through `requirements_plotting.txt`. Windows execution is tested. Linux commands are conventional installation instructions and are not claimed as a separately tested platform.

The package reproduces statistics from frozen predictions. It does not rerun the original cross-validation training, point-cloud reconstruction, silhouette extraction, mobile application, or the full final manuscript layout.
