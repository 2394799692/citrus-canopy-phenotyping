# Release validation

The public companion was prepared on 2026-10-29 and executed using the existing isolated Windows Python 3.10.18 environment, with NumPy 1.26.4 and pandas 2.3.3. It is based on the supplied minimal statistical package and does not include a new model fit.

| Check | Outcome |
|---|---|
| Principal frozen predictions loaded | 18435 rows |
| Principal model performance recalculated | 40 rows |
| Largest absolute metric difference from frozen values | 1.78e-15 |
| Allowed comparison tolerance | 1e-10 |
| Expanded315 holdout and matched controls | Frozen comparison assertions passed |
| Expanded466 branch | Available frozen comparison assertions passed |
| Regression models fitted by the workflow | 0 |
| Core executable data, scripts and expected results | Byte-identical to the supplied package |
| Public SourceData metadata edits | 21 CSV files; 3672 local path cells converted to source-ref identifiers |
| Other CSV cell strings and row/column order | Preserved and checked during preparation |
| Patent application fields | Checked against the supplied CNIPA acceptance notice |
| Original manuscript and input ZIP | Retained unchanged |

The published ZIP was extracted into a separate test directory and its integrity verifier and statistical entry point were run from the extracted repository. Local logs and the private reverse provenance map are retained by the authors, outside the public ZIP.

The first source package's checksum list referenced a missing top-level README. The public companion adds its own documentation and regenerates the full checksum list. The current authority is the root `SHA256.json`.

This validation covers the supplied frozen statistical inputs and specified computations. It does not claim a new field test, model retraining, new mobile application validation, Linux execution, or independent download verification of the Zenodo archive. External-tool link-check scope is recorded in [COMPANION_TOOLS.md](COMPANION_TOOLS.md).
