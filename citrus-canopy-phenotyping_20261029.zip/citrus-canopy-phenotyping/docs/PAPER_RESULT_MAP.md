# Manuscript evidence map

The supplied manuscript is an author-edited working version. The SourceData filenames retain original experiment identifiers for traceability; these identifiers are not new scientific methods. Match by analysis scope before matching a figure number.

| Scientific component | Active evidence |
|---|---|
| Main matched model comparison | `data/principal_predictions.csv`, `data/frozen_performance.csv` |
| Model and crown-form stratification | `SourceData/principal315_models_by_final_crown_form.csv` |
| Geometry/silhouette gains | `SourceData/principal_models_final_paired_contrasts.csv`; historical complete view tables under `archive_E48/supplementary/TableS05/` |
| Second orthogonal view and correspondence | `archive_E48/supplementary/TableS05/` and `TableS06/` |
| Expanded manual crown-form holdout | `data/loco_predictions.csv`, `data/frozen_loco_performance.csv`; corresponding expanded315 SourceData summaries |
| Historical and September transfer | Principal prediction inputs and `SourceData/principal315_frozen_models_final_performance.csv` |
| Expanded training | `data/expanded466_predictions.csv`, `data/frozen_expanded466_performance.csv` |
| Fixed-alpha reference scale response | `SourceData/archive_E48/supplementary/TableS18/` and `TableS19/` |
| Input / spatial point-cloud sensitivity | `SourceData/archive_E48/supplementary/TableS14/` and `TableS16/` |
| Prediction interval reliability | `SourceData/calibrated_submodel_intervals_final_retained.csv`, identity diagnostics; interval fitting differs from full315 point models |
| Narrow hedge-form structural diagnostics | `SourceData/hedge19_all_cases_diagnostic.csv`, `held_form_feature_support.csv`, saved model decompositions |
| DR reference coverage | `SourceData/DR_reference_coverage_final108_*.csv` |
| Companion reconstruction / mobile workflow | `docs/COMPANION_TOOLS.md`; software is distributed separately |

The executable script recalculates saved-prediction metrics and specified conditional intervals. The complete technical experiment tables are distributed as evidence without claiming every upstream simulation/reconstruction is rerun by that single script.
