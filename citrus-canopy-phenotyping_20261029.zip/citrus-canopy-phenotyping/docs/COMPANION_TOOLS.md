# Companion archive and applications

| Resource | Access | Role |
|---|---|---|
| Earlier public data and reconstruction release | https://doi.org/10.5281/zenodo.16562849 | LiDAR point clouds, RGB canopy images, and a Windows reconstruction application, as described by the authors |
| Zhonggan Huiju Android application | https://down.scxys.com/aims-v2.0/farming-apps-down.html | Field-oriented structural inference demonstration and individual-tree recording; trial access through the authors |
| This repository | Local `data/` and statistical scripts | Recalculate manuscript statistics from saved predictions and references |

## Windows reconstruction application

The previously released application implements DR canopy-volume reconstruction and AS outer-canopy surface-area reconstruction. It accepts individual-tree point-cloud files, supports single-tree and batch processing, and does not require MATLAB. These capabilities describe the released desktop tool; the statistical scripts in this repository do not reconstruct DR/AS surfaces.

The Zenodo release is separate from the final 627-observation analysis archive. Match file identities, reconstruction settings, and version coverage using the release documentation. Do not assume identical raw-data coverage from the common project topic alone.

## Zhonggan Huiju

The Android application used in the manuscript demonstration provides a workflow connecting crown measurements, canopy images, structural estimation, and tree/orchard records. A trial account can be requested from the corresponding authors. The public download landing page identifies the application as 中柑慧橘APP; it is separate from the Windows reconstruction program.

This repository does not contain the complete Android source, private accounts, service credentials, model-deployment endpoint, or an installer mirror. Application release management remains with its developers. Runtime speed and photo/LiDAR agreement values are not supplied here without corresponding validation evidence.

## Link-check scope for this preparation

On 2026-10-29 the Android landing page returned HTTP 200 and identified the Android application. No app installation, login, or function-level test was performed in this packaging task. The Zenodo DOI is the author-supplied public release identifier; automated DOI/record retrieval was blocked or unavailable during preparation, so its current file list and download integrity were not independently rechecked. The archive/tool descriptions above follow the author's release description. No archive bibliographic authorship, release year, or version number has been guessed.
